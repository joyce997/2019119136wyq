
# 变量的大(小)尾存储方式和字节对齐方式

    用 C语言和MDK编译器研究 ARM 的内存变量的大(小)尾存储方式和字节对齐方式，理解CPU 和编译器为何如此处理。

# 参考资料

    字节存放顺序：大尾，小尾https://blog.csdn.net/ll641058431/article/details/46853115
    C/C++内存对齐详解https://zhuanlan.zhihu.com/p/30007037
