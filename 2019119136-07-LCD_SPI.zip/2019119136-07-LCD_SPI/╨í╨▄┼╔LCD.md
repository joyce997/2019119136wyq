
# 小熊派LCD实验

    实验七：使用小熊派 IoT实验套件和STM32CubeMX，根据 IoT的开发资料，编写在 LCD 上显示字符（包含汉字），和简单几何图形的 LCD 驱动库。并在此驱动库基础上，给出几个显示样例。

# 参考资料

    开源社区的教程有遗漏所以另外找了一篇博客https://blog.csdn.net/qq_39400113/article/details/115605050
